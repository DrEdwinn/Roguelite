#include "carte.h"
#include "jeu.h"
#include "SDL.h"
#include "SDL_image.h"
#include <stdio.h>
#include <stdlib.h>

Image* carrelage;
Image* mur;
Image* eau;
Image* herbe;

void charger_carte(void){
    FILE* fichier=fopen("carte.txt","r");
    if (!fichier){
        printf("erreur chargement fichier carte");
        exit(0);
    }
    int i,j;
    char c;
    Cellule cel;
    for (i=0;i<CARTE_LONGUEUR;i++){
        for (j=0;j<CARTE_LARGEUR;j++){
            fscanf(fichier,"%c",&c);
            switch(c){
            case '#':
                cel=MUR;
                break;
            case '~':
                cel=EAU;
                break;
            case '.':
                cel=VIDE;
                break;
            case '_':
                cel=CARRELAGE;
                break;
            case '"':
                cel=HERBE;
                break;
            }
            carte.map_cel[i][j]=cel;
        }
        fscanf(fichier,"\n");

    }
    fclose(fichier);
    carrelage=init_img("images/carrelage.png",64);
    mur=init_img("images/mur.png", 64);
    eau=init_img("images/eau.png", 64);
    herbe=init_img("images/herbe.png", 64);
}

void aff_carte(void){

    int i,j;
    for (i=0;i<CARTE_LONGUEUR;i++){
        for (j=0;j<CARTE_LARGEUR;j++){
            switch(carte.map_cel[i][j]){
            case MUR:
                aff_img(mur, j*TAILLE_CEL,i*TAILLE_CEL,  nb_bordure(i,j));
                break;
            case EAU:
                aff_img(eau, j*TAILLE_CEL, i*TAILLE_CEL, nb_bordure(i,j));
                break;
            case CARRELAGE:
                aff_img(carrelage, j*TAILLE_CEL, i*TAILLE_CEL, 0);
                break;
            case VIDE:
                break;
            case HERBE:
                aff_img(herbe, j*TAILLE_CEL, i*TAILLE_CEL, nb_bordure(i,j));
                break;
            }
        }
    }
}

int nb_bordure(int i, int j){
    int res=0;
    Cellule cel = carte.map_cel[i][j];
    if (j!=CARTE_LARGEUR && carte.map_cel[i][j+1]==cel) res+=1;
    if (i!=0 && carte.map_cel[i-1][j]==cel) res+=2;
    if (j!=0 && carte.map_cel[i][j-1]==cel) res+=4;
    if (i!=CARTE_LONGUEUR && carte.map_cel[i+1][j]==cel) res+=8;
    return res;
}


void imprimer_cel(Cellule cel){
    switch(cel){
    case MUR:
        printf("#");
        break;
    case CARRELAGE:
        printf("_");
        break;
    case EAU:
        printf("~");
        break;
    case VIDE:
        printf(".");
        break;
    case HERBE:
        printf("\"");
        break;
    }
}


void imprimer_carte(void){
    int i,j;
    for (i=0;i<CARTE_LONGUEUR;i++){
        for (j=0;j<CARTE_LARGEUR;j++){
            imprimer_cel(carte.map_cel[i][j]);
        }
        printf("\n");
    }
}

int est_obstacle(Cellule cel){
    return (cel==MUR || cel==EAU);
}


void avance_droite(Personnage* player){
    int i=0,j=0,i2=0;
    i=(player->y+player->hitbox.y)/TAILLE_CEL;
    j=(player->x+player->hitbox.x+player->hitbox.w+player->vitesse)/TAILLE_CEL;
    i2=(player->y+player->hitbox.y+player->hitbox.h)/TAILLE_CEL;
    if (!est_obstacle(carte.map_cel[i][j]) && !est_obstacle(carte.map_cel[i2][j])){
        player->x+=player->vitesse;
    }
    else{
        player->x+=(j*TAILLE_CEL-(player->x+player->hitbox.x+player->hitbox.w+1));
    }
}

void avance_gauche(Personnage* player){
    int i=0,j=0,i2=0;
    i=(player->y+player->hitbox.y)/TAILLE_CEL;
    j=(player->x+player->hitbox.x-player->vitesse)/TAILLE_CEL;
    i2=(player->y+player->hitbox.y+player->hitbox.h)/TAILLE_CEL;
    if (!est_obstacle(carte.map_cel[i][j]) && !est_obstacle(carte.map_cel[i2][j])){
        player->x-=player->vitesse;
    }
    else{
        player->x-=((player->x+player->hitbox.x-1)-(j+1)*TAILLE_CEL);
    }
}

void avance_haut(Personnage* player){
    int i=0,j=0,j2=0;
    i=(player->y+player->hitbox.y-player->vitesse)/TAILLE_CEL;
    j=(player->x+player->hitbox.x)/TAILLE_CEL;
    j2=(player->x+player->hitbox.x+player->hitbox.w)/TAILLE_CEL;
    if (!est_obstacle(carte.map_cel[i][j]) && !est_obstacle(carte.map_cel[i][j2])){
        player->y-=player->vitesse;
    }
    else{
        player->y-=((player->y+player->hitbox.y-1)-(i+1)*TAILLE_CEL);
    }
}

void avance_bas(Personnage* player){
    int i=0,j=0,j2=0;
    i=(player->y+player->hitbox.y+player->hitbox.h+player->vitesse)/TAILLE_CEL;
    j=(player->x+player->hitbox.x)/TAILLE_CEL;
    j2=(player->x+player->hitbox.x+player->hitbox.w)/TAILLE_CEL;
    if (!est_obstacle(carte.map_cel[i][j]) && !est_obstacle(carte.map_cel[i][j2])){
        player->y+=player->vitesse;
    }
    else{
        player->y+=i*TAILLE_CEL-(player->y+player->hitbox.y+player->hitbox.h+1);
    }
}
